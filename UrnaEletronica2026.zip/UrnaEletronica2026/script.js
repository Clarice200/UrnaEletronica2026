/* CANDIDATOS */

const candidatos = {
    "01": "Alberto Rodrigues de Moura Neto",
    "02": "Andre Mota Dias",
    "03": "Clarice Barbosa do Lago",
    "04": "Francisco Alves dos Reis",
    "05": "Isnadia Rodrigues de Sousa",
    "06": "Janice Soares da Silva",
    "07": "Julio Cesar Herculano Ferreira de Mesquita",
    "08": "Lara Sthefany Feitosa de Miranda",
    "09": "Luciene Martins Pinto",
    "10": "Luis Fabiano Rodrigues de Sousa",
    "11": "Maria Stheffany de Oliveira Fernandes",
    "12": "Raniel Rodrigues de Amorim",
    "13": "Rauander Brito de Sousa"
};


/* FOTOS DOS CANDIDATOS */

const fotos = {
    "01": "Alberto.jpg",
    "02": "Andre.jpg",
    "03": "Clarice.jpg",
    "04": "Francisco.jpg",
    "05": "Isnadia.jpg",
    "06": "Janice.jpg",
    "07": "Julio.jpg",
    "08": "Lara.jpg",
    "09": "Luciene.jpg",
    "10": "Luis.jpg",
    "11": "Maria.jpg",
    "12": "Raniel.jpg",
    "13": "Rauander.jpg"
};


/* CONTAGEM DOS VOTOS */

let votos = {};
let votosBrancos = 0;

for (let numero in candidatos) {
    votos[numero] = 0;
}


/* DIGITAR NÚMERO */

function digitar(numero) {
    const campo1 = document.getElementById("numero1");
    const campo2 = document.getElementById("numero2");

    if (!campo1 || !campo2) return;

    if (campo1.value === "") {
        campo1.value = numero;
    } else if (campo2.value === "") {
        campo2.value = numero;
        mostrarCandidato();
    }
}


/* MOSTRAR CANDIDATO E FOTO */

function mostrarCandidato() {
    const campo1 = document.getElementById("numero1");
    const campo2 = document.getElementById("numero2");
    const nome = document.getElementById("nome");
    const foto = document.getElementById("foto");

    if (!campo1 || !campo2 || !nome || !foto) return;

    const numero = campo1.value + campo2.value;

    if (candidatos[numero]) {
        nome.innerText = candidatos[numero];
        foto.src = "./fotos/" + fotos[numero];
        foto.style.display = "block";
    } else {
        nome.innerText = "CANDIDATO NÃO ENCONTRADO";
        foto.src = "";
        foto.style.display = "none";
    }
}


/* CORRIGIR VOTO */

function corrige() {
    const campo1 = document.getElementById("numero1");
    const campo2 = document.getElementById("numero2");
    const nome = document.getElementById("nome");
    const foto = document.getElementById("foto");

    if (campo1) campo1.value = "";
    if (campo2) campo2.value = "";
    if (nome) nome.innerText = "";

    if (foto) {
        foto.src = "";
        foto.style.display = "none";
    }
}


/* TOCAR SOM DA URNA */

function tocarSomUrna() {
    const som = document.getElementById("somUrna");

    if (!som) {
        console.error("Áudio não encontrado. Confira o index.html.");
        return;
    }

    som.currentTime = 0;

    som.play().catch(erro => {
        console.error("Não foi possível tocar o áudio:", erro);
    });
}


/* FINALIZAR VOTAÇÃO */

function finalizarVotacao() {
    const tela = document.querySelector(".tela");

    if (!tela) {
        console.error('Não encontrei o elemento com a classe ".tela".');
        return;
    }

    tela.innerHTML = `
        <div class="fim-votacao">
            FIM
            <span>VOTOU</span>
        </div>
    `;

    tocarSomUrna();
}


/* CONFIRMAR VOTO */

function confirma() {
    const campo1 = document.getElementById("numero1");
    const campo2 = document.getElementById("numero2");

    if (!campo1 || !campo2) return;

    const numero = campo1.value + campo2.value;

    if (candidatos[numero]) {
        votos[numero]++;
        finalizarVotacao();
    } else {
        const nome = document.getElementById("nome");

        if (nome) {
            nome.innerText = "CANDIDATO NÃO ENCONTRADO";
        }
    }
}


/* VOTO EM BRANCO */

function branco() {
    votosBrancos++;
    finalizarVotacao();
}


/* APURAÇÃO */

function apuracao() {
    let resultado = "RESULTADO DA ELEIÇÃO:\n\n";

    for (let numero in candidatos) {
        resultado +=
            numero + " - " +
            candidatos[numero] + ": " +
            votos[numero] + " voto(s)\n";
    }

    resultado += "\nVOTOS EM BRANCO: " + votosBrancos;

    alert(resultado);
}